"""Execute the three authorized single-request 2% cases and retain audit evidence."""

import os
import sys
import shutil
import logging
from pathlib import Path
from urllib.parse import urlsplit

from dotenv import dotenv_values

sys.path.append(os.getcwd())

from adaptive_encoding.core import save_json
from adaptive_encoding.experiments import create_run, execute_jobs
from adaptive_encoding.core import Context

logger = logging.getLogger(__name__)


def main():
    """Run one fresh model decision per held-out source and persist receipts."""
    dataset = Path("CS5185_Project_Video_Dataset")
    folder = create_run("runs", "full_ark_cases")
    shutil.copy2(__file__, folder / "source" / "ark_cases.py")
    config = dotenv_values(".env", interpolate = False)
    url = os.environ.get("LLM_API_BASE_URL") or config.get("LLM_API_BASE_URL")
    host = urlsplit(url or "https://ark.cn-beijing.volces.com/api/v3").hostname
    for key in ("NO_PROXY", "no_proxy"):
        os.environ[key] = ",".join(filter(None, [os.environ.get(key), host]))

    jobs = []
    for name in ("10_Stockholm", "11_Sintel", "12_ControlledBurn"):
        jobs.append({
            "source": dataset / (name + ".mp4"),
            "name": name + "_0.02_llm",
            "strategy": "llm",
            "ratio": 0.02,
            "max_attempts": 1,
        })
    records = execute_jobs(jobs, folder, Context())
    receipts = []
    for record in records:
        attempts = record["attempts"]
        if len(attempts) > 1:
            raise RuntimeError("Request cap exceeded")
        attempt = attempts[0] if attempts else {}
        receipts.append({
            "video": record["video_id"],
            "budget_pct": 2,
            "status": record["status"],
            "attempt_status": attempt.get("status"),
            "llm": attempt.get("llm"),
            "decision": attempt.get("decision"),
            "actual_bytes": attempt.get("actual_bytes"),
            "target_bytes": record.get("target_bytes"),
            "output_sha256": record.get("output_sha256"),
            "psnr_y_db": (attempt.get("metrics") or {}).get("psnr_y_db"),
            "ms_ssim_y": (attempt.get("metrics") or {}).get("ms_ssim"),
            "failure_reason": record.get("failure_reason"),
        })
    save_json(Path("experiments/full_exps/ark_cases.json"), {"run": str(folder), "cases": receipts})


if __name__ == "__main__":
    main()
